package AgentCreation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import BaseLayerPackage.BaseClass;
import UtilsLayerPackage.ExcelReader;

public class CBI_Create_new_CPRC extends BaseClass{

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
BaseLayerPackage.BaseClass.CBIReport();
		
		Thread.sleep(2000);
		WebElement Username = driver.findElement(By.xpath("//input[@id='usernaname']"));
		Username.sendKeys("admin@helpdesk.com");
		Thread.sleep(2000);
		WebElement Password = driver.findElement(By.xpath("//input[@id='password']"));
		Password.sendKeys("12345");
		Thread.sleep(2000);
		WebElement Submit = driver.findElement(By.xpath("//button[@type='submit']"));
		Submit.click();
		Thread.sleep(2000);
		WebElement Setting = driver.findElement(By.xpath("//span[text()=' settings ']"));
		Setting.click();
		Thread.sleep(2000);
		WebElement loginMaster = driver.findElement(By.xpath("//div[@routerlink='/Masters/loginmaster']"));
		loginMaster.click();
		Thread.sleep(5000);
		ExcelReader excel = new ExcelReader("C:\\Users\\cognicx\\eclipse-workspace\\CBI\\CBI Excel Sheet\\CBI_Account_creator.xlsx");
		
		for(int i=27 ; i<=100;i++) {
		WebElement Create_Login_Master = driver.findElement(By.xpath("//button[text()=' Create Login Master ']"));
		new Actions(driver).moveToElement(Create_Login_Master).click().build().perform();
		Thread.sleep(1500);
		String Name1 = excel.getDataFromExcelSheet(0, i, 4);
		WebElement Name = driver.findElement(By.xpath("//input[@id='mat-input-1']"));
		Name.sendKeys(Name1);
		Thread.sleep(1500);
		String Username1 = excel.getDataFromExcelSheet(0, i, 5);
		WebElement username = driver.findElement(By.xpath("//input[@id='mat-input-2']"));
		username.sendKeys(Username1);
		Thread.sleep(1500);
		String Email1 = excel.getDataFromExcelSheet(0, i, 6);
		WebElement Email = driver.findElement(By.xpath("//input[@id='mat-input-4']"));
		Email.sendKeys(Email1);
		Thread.sleep(1500);
		WebElement Role = driver.findElement(By.xpath("//div[@id='mat-select-value-1']"));
		Role.click();
		
		Thread.sleep(2000);
		WebElement cprc = driver.findElement(By.xpath("//span[text()=' CPRC User ']"));
		cprc.click();
		Thread.sleep(1500);
		Email.click();
		
		Thread.sleep(1500);
		WebElement department = driver.findElement(By.xpath("//label[@id='mat-mdc-form-field-label-12']"));
		department.click();
		
		Thread.sleep(1500);
		WebElement sale = driver.findElement(By.xpath("//mat-option[@id='mat-option-5']"));
		sale.click();
		
		Thread.sleep(1500);
		WebElement create = driver.findElement(By.xpath("//button[text()=' Create ']"));
		new Actions(driver).doubleClick(create).build().perform();
		Thread.sleep(8000);
		}
	}

}
