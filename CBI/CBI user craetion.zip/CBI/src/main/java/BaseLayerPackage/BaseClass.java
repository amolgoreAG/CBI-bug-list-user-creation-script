package BaseLayerPackage;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;


public class BaseClass {

	public static WebDriver driver;

	public static void CBIReport() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\cognicx\\eclipse-workspace\\CBI\\driver\\chromedriver.exe");
		ChromeOptions option = new ChromeOptions();
		option.addArguments("--remote-allow-origins=*");
		option.addArguments("use-fake-ui-for-media-stream");
		driver = new ChromeDriver(option);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
		driver.manage().window().maximize();
		driver.get("https://cms.inaipiapp.com/helpdesk_cbi");
	}
	
}
